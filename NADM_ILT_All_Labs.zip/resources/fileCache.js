(function(global) {
  // fileCache.js without query param "guids"

  var fileCacheJS = {

    /**
    * The pattern below, everything between {_{#guids}_} and {_{/guids}_} will be repeated for every item of the "guids" collection.
    * {_{.}_} (without _) will be replaced with the item of the collection "guids", which is defined in the "context", see JsFileCacheWriter.java
    * the result will look like this:
    * '4ef18c14-40ec-4443-b0a5-1c0d5c7b8702.html': createPromise(),
    * 'a26a1d7d-7f7f-488e-b5dc-be9830c07db6.html': createPromise(),
    * .....
    * 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx.html': createPromise(),
    * for more info see https://mustache.github.io/
    */
    // 
    '9d308b88-cbd3-44fe-98ec-7eea50b9b5d8.html': createPromise(), 
    '48f29e47-4ca1-4185-b34c-e5ffc9dc15bf.html': createPromise(), 
    'e4631040-28e4-4963-9e7a-7543fa453984.html': createPromise(), 
    '98038ca0-b1e9-41c9-b77b-e0446a8a4a42.html': createPromise(), 
    '4d7d07ef-12a7-4064-b349-d41a8cc514f8.html': createPromise(), 
    'ef103d05-8898-48a9-89ca-8d214ac413ec.html': createPromise(), 
    'd7290b3a-2bd3-44d8-951b-6c868745ca33.html': createPromise(), 
    'aaf9b820-f51d-44d7-a075-5d9ef849e116.html': createPromise(), 
    'c909b046-31b5-492d-a7e8-50840f2f02f9.html': createPromise(), 
    '7bdb0336-0360-4b57-b4d8-8390efacf2b6.html': createPromise(), 
    '7d390c0f-a8d4-40ad-9a8d-1bc7015acfee.html': createPromise(), 
    'db608191-ddee-4871-afad-1a0cffe0ef27.html': createPromise(), 
    '5a2aaeb7-0575-42fc-87f6-bedb4b626857.html': createPromise(), 
    '74c70a6a-e3ac-43d4-9845-9fcc6ad25906.html': createPromise(), 
    'bad14c57-f965-4fc0-a577-715c4e4c4841.html': createPromise(), 
    '20c2cf62-9ad4-4c49-9e7f-79720f29b76b.html': createPromise(), 
    '63ffba65-0c99-4f53-9f7f-115381917924.html': createPromise(), 
    'b690016f-f8f0-472d-9de2-730038c2614b.html': createPromise(), 
    '4327a71f-083c-4d5f-9fa6-7b3121d3686e.html': createPromise(), 
    'd418d255-1598-477b-8152-41c441e5a956.html': createPromise(), 
    'e970a12f-1369-4286-bc9f-36440a16483c.html': createPromise(), 
    '87b10c6e-26b5-4872-9c21-91cad136ad0f.html': createPromise(), 
    'e18abe82-1256-4c7c-b6d0-4748579e68ec.html': createPromise(), 
    '4d97825c-8190-4fd4-852b-cddadb87c5ff.html': createPromise(), 
    'ab9538cb-6244-4be1-818b-dd00e10ec3fb.html': createPromise(), 
    '10896567-9920-454a-84f8-34f6e0a7652b.html': createPromise(), 
    '76772217-602e-4e6e-b868-400220726767.html': createPromise(), 
    '2877963e-77a4-461c-95db-b3c5f33461aa.html': createPromise(), 
    'c8537f1e-1006-45eb-b8e8-c17c978066f6.html': createPromise(), 
    '36a5578c-d40e-49d5-a9da-612b397557cb.html': createPromise(), 
    '18af083f-dace-4065-b6ef-9c134031a852.html': createPromise(), 
    '052bc42e-0bde-4343-85ed-10f15ce16f1f.html': createPromise(), 
    'be313953-52a0-4668-a901-b3d012f15015.html': createPromise(), 
    '794aa9b0-00cc-4459-9330-9d0e96b5e631.html': createPromise(), 
    'ccd058e2-e4a3-4a98-91a5-5d619ec5b99a.html': createPromise(), 
    '13ae0089-1db2-4c80-96b6-ec09784ff07b.html': createPromise(), 
    '989f5893-a1f4-41a5-abcb-13e5d26090f6.html': createPromise(), 
    '2b5e78a4-bd6b-4398-9007-fe00d6c6d3c4.html': createPromise(), 
    '15a22bc6-73fc-4fca-a14d-0380bb7aa554.html': createPromise(), 
    '85593825-be3a-421b-a503-6aba2d0c589b.html': createPromise(), 
    '9a8018f5-a12c-4b8c-902e-89615c7ace16.html': createPromise(), 
    '0014298d-6b2c-44d3-8559-f51aa49c75b7.html': createPromise(), 
    'f2328b2c-af24-41a7-ace8-b6723e10bd64.html': createPromise(), 
    '6318c2cd-eded-4911-baea-494856fa366e.html': createPromise(), 
    '907eee9f-f2bb-42cf-99b1-b89113171bb7.html': createPromise(), 
    'f4dcffa0-9fc9-430d-9905-dd56cfa1e060.html': createPromise(), 
    '9a2688d1-7e56-4819-999a-5fcdae6ddb43.html': createPromise(), 
    '40098b48-e1e6-4ba2-9698-5eb2baddfce4.html': createPromise(), 
    '009730f8-3417-476e-aba0-e872d40a59df.html': createPromise(), 
    '261d5e6e-4778-49af-9f86-448229bb66c5.html': createPromise(), 
    '064c8652-b7ff-4bc2-a766-abd3024b8dcb.html': createPromise(), 
    'bed4b646-84fb-4ecd-b151-931eb4a90007.html': createPromise(), 
    '1c666650-858d-45ff-9b37-c646c6290e24.html': createPromise(), 
    '7f25efc7-0c4b-4253-9c86-76de74b6413b.html': createPromise(), 
    'c73f84d0-ed98-4a81-88ff-0cc0df24b5da.html': createPromise(), 
    'a2dd1cb3-d156-4f8a-8514-42e05d16d860.html': createPromise(), 
    '7f2d38de-98c6-48ee-a9c4-3641393bf92b.html': createPromise(), 
    'b49f1d42-191c-45ad-9f86-2582f8898acf.html': createPromise(), 
    '84101fa0-e3b9-4241-a8f1-fabe5a66ff28.html': createPromise(), 
    '8a6744af-668b-4d45-b34d-d6486d6a32b4.html': createPromise(), 
    '53b494f9-b78e-4a94-911c-b7893ff5c5ed.html': createPromise(), 
    'c2b6f471-1d52-4399-a0ce-9069e002d96e.html': createPromise(), 
    'c70a429d-37c4-4214-9b95-f2ac8e53ec1d.html': createPromise(), 
    '1187723e-8254-49e7-a440-cb26ab411c2d.html': createPromise(), 
    '2ca7d8e2-3a99-4ab8-a19b-46080be0cf46.html': createPromise(), 
    'b43bcaad-ef72-474a-ae6a-b76f7793c9db.html': createPromise(), 
    '5f42ad56-faf6-4758-8228-4a19adc919b6.html': createPromise(),  //<-- end of repeated part

    resolve: function fileCacheJSResolve(guid, content) {
      var promise = fileCacheJS[guid];

      if (!promise) {
        // log error
        return;
      }

      promise.resolve(content);
    }
  };

  function createPromise() {
    var resolve;
    var reject;

    var p = new Promise(function(res, rej) {
      resolve = res;
      reject = rej;
    });

    p.resolve = resolve;
    p.reject = reject;
    var then = p.then.bind(p);

    var listeners = [];

    p.onThen = function (listener) {
      listeners.push(listener);
    };

    p.then = function (success, failed) { // detect when called
      listeners.forEach(function (fn) {
        fn();
      });

      return then(success, failed);
    };

    return p;
  }


    /**
     * The pattern below, everything between {_{#batchPathNames}_} and {_{/batchPathNames}_} will be expanded to the array of string
     * using the content of the "batchPathNames" collection. The result will look like this:
     * batchPathNames = ['resources/fileCacheBatch_1.js', 'resources/fileCacheBatch_2.js', ...'resources/fileCacheBatch_N.js'];
     * see JsFileCacheWriter.java and https://mustache.github.io/
     */
  var batchPathNames = [
      // 
      'resources/fileCacheBatch_5.js', 
      'resources/fileCacheBatch_2.js', 
      'resources/fileCacheBatch_1.js', 
      'resources/fileCacheBatch_7.js', 
      'resources/fileCacheBatch_8.js', 
      'resources/fileCacheBatch_6.js', 
      'resources/fileCacheBatch_3.js', 
      'resources/fileCacheBatch_4.js', 
      'resources/fileCacheBatch_14.js', 
      'resources/fileCacheBatch_12.js', 
      'resources/fileCacheBatch_13.js', 
      'resources/fileCacheBatch_10.js', 
      'resources/fileCacheBatch_11.js', 
      'resources/fileCacheBatch_9.js'  //<--end of repeated part
      ];

    /**
     * The pattern below, everything between {_{#guidBatchMap}_} and {_{/guidBatchMap}_} will be expanded to the map of string to string
     * using the content of the "guidBatchMap" map. The result will look like this:
     * guidsBatchMap = {
     * '4ef18c14-40ec-4443-b0a5-1c0d5c7b8702.html' : 'resources/fileCacheBatch_1.js',
     * 'a26a1d7d-7f7f-488e-b5dc-be9830c07db6.html' : 'resources/fileCacheBatch_2.js',
     * ....
     * 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx.html' : 'resources/fileCacheBatch_N.js'
     * };
     * see JsFileCacheWriter.java and https://mustache.github.io/
     */
  var guidsBatchMap = {
    // 
        '9d308b88-cbd3-44fe-98ec-7eea50b9b5d8.html' : 'resources/fileCacheBatch_1.js', 
        '48f29e47-4ca1-4185-b34c-e5ffc9dc15bf.html' : 'resources/fileCacheBatch_1.js', 
        'e4631040-28e4-4963-9e7a-7543fa453984.html' : 'resources/fileCacheBatch_1.js', 
        '98038ca0-b1e9-41c9-b77b-e0446a8a4a42.html' : 'resources/fileCacheBatch_1.js', 
        '4d7d07ef-12a7-4064-b349-d41a8cc514f8.html' : 'resources/fileCacheBatch_1.js', 
        'ef103d05-8898-48a9-89ca-8d214ac413ec.html' : 'resources/fileCacheBatch_2.js', 
        'd7290b3a-2bd3-44d8-951b-6c868745ca33.html' : 'resources/fileCacheBatch_2.js', 
        'aaf9b820-f51d-44d7-a075-5d9ef849e116.html' : 'resources/fileCacheBatch_2.js', 
        'c909b046-31b5-492d-a7e8-50840f2f02f9.html' : 'resources/fileCacheBatch_2.js', 
        '7bdb0336-0360-4b57-b4d8-8390efacf2b6.html' : 'resources/fileCacheBatch_2.js', 
        '7d390c0f-a8d4-40ad-9a8d-1bc7015acfee.html' : 'resources/fileCacheBatch_3.js', 
        'db608191-ddee-4871-afad-1a0cffe0ef27.html' : 'resources/fileCacheBatch_3.js', 
        '5a2aaeb7-0575-42fc-87f6-bedb4b626857.html' : 'resources/fileCacheBatch_3.js', 
        '74c70a6a-e3ac-43d4-9845-9fcc6ad25906.html' : 'resources/fileCacheBatch_3.js', 
        'bad14c57-f965-4fc0-a577-715c4e4c4841.html' : 'resources/fileCacheBatch_3.js', 
        '20c2cf62-9ad4-4c49-9e7f-79720f29b76b.html' : 'resources/fileCacheBatch_4.js', 
        '63ffba65-0c99-4f53-9f7f-115381917924.html' : 'resources/fileCacheBatch_4.js', 
        'b690016f-f8f0-472d-9de2-730038c2614b.html' : 'resources/fileCacheBatch_4.js', 
        '4327a71f-083c-4d5f-9fa6-7b3121d3686e.html' : 'resources/fileCacheBatch_4.js', 
        'd418d255-1598-477b-8152-41c441e5a956.html' : 'resources/fileCacheBatch_4.js', 
        'e970a12f-1369-4286-bc9f-36440a16483c.html' : 'resources/fileCacheBatch_5.js', 
        '87b10c6e-26b5-4872-9c21-91cad136ad0f.html' : 'resources/fileCacheBatch_5.js', 
        'e18abe82-1256-4c7c-b6d0-4748579e68ec.html' : 'resources/fileCacheBatch_5.js', 
        '4d97825c-8190-4fd4-852b-cddadb87c5ff.html' : 'resources/fileCacheBatch_5.js', 
        'ab9538cb-6244-4be1-818b-dd00e10ec3fb.html' : 'resources/fileCacheBatch_5.js', 
        '10896567-9920-454a-84f8-34f6e0a7652b.html' : 'resources/fileCacheBatch_6.js', 
        '76772217-602e-4e6e-b868-400220726767.html' : 'resources/fileCacheBatch_6.js', 
        '2877963e-77a4-461c-95db-b3c5f33461aa.html' : 'resources/fileCacheBatch_6.js', 
        'c8537f1e-1006-45eb-b8e8-c17c978066f6.html' : 'resources/fileCacheBatch_6.js', 
        '36a5578c-d40e-49d5-a9da-612b397557cb.html' : 'resources/fileCacheBatch_6.js', 
        '18af083f-dace-4065-b6ef-9c134031a852.html' : 'resources/fileCacheBatch_7.js', 
        '052bc42e-0bde-4343-85ed-10f15ce16f1f.html' : 'resources/fileCacheBatch_7.js', 
        'be313953-52a0-4668-a901-b3d012f15015.html' : 'resources/fileCacheBatch_7.js', 
        '794aa9b0-00cc-4459-9330-9d0e96b5e631.html' : 'resources/fileCacheBatch_7.js', 
        'ccd058e2-e4a3-4a98-91a5-5d619ec5b99a.html' : 'resources/fileCacheBatch_7.js', 
        '13ae0089-1db2-4c80-96b6-ec09784ff07b.html' : 'resources/fileCacheBatch_8.js', 
        '989f5893-a1f4-41a5-abcb-13e5d26090f6.html' : 'resources/fileCacheBatch_8.js', 
        '2b5e78a4-bd6b-4398-9007-fe00d6c6d3c4.html' : 'resources/fileCacheBatch_8.js', 
        '15a22bc6-73fc-4fca-a14d-0380bb7aa554.html' : 'resources/fileCacheBatch_8.js', 
        '85593825-be3a-421b-a503-6aba2d0c589b.html' : 'resources/fileCacheBatch_8.js', 
        '9a8018f5-a12c-4b8c-902e-89615c7ace16.html' : 'resources/fileCacheBatch_9.js', 
        '0014298d-6b2c-44d3-8559-f51aa49c75b7.html' : 'resources/fileCacheBatch_9.js', 
        'f2328b2c-af24-41a7-ace8-b6723e10bd64.html' : 'resources/fileCacheBatch_9.js', 
        '6318c2cd-eded-4911-baea-494856fa366e.html' : 'resources/fileCacheBatch_9.js', 
        '907eee9f-f2bb-42cf-99b1-b89113171bb7.html' : 'resources/fileCacheBatch_9.js', 
        'f4dcffa0-9fc9-430d-9905-dd56cfa1e060.html' : 'resources/fileCacheBatch_10.js', 
        '9a2688d1-7e56-4819-999a-5fcdae6ddb43.html' : 'resources/fileCacheBatch_10.js', 
        '40098b48-e1e6-4ba2-9698-5eb2baddfce4.html' : 'resources/fileCacheBatch_10.js', 
        '009730f8-3417-476e-aba0-e872d40a59df.html' : 'resources/fileCacheBatch_10.js', 
        '261d5e6e-4778-49af-9f86-448229bb66c5.html' : 'resources/fileCacheBatch_10.js', 
        '064c8652-b7ff-4bc2-a766-abd3024b8dcb.html' : 'resources/fileCacheBatch_11.js', 
        'bed4b646-84fb-4ecd-b151-931eb4a90007.html' : 'resources/fileCacheBatch_11.js', 
        '1c666650-858d-45ff-9b37-c646c6290e24.html' : 'resources/fileCacheBatch_11.js', 
        '7f25efc7-0c4b-4253-9c86-76de74b6413b.html' : 'resources/fileCacheBatch_11.js', 
        'c73f84d0-ed98-4a81-88ff-0cc0df24b5da.html' : 'resources/fileCacheBatch_11.js', 
        'a2dd1cb3-d156-4f8a-8514-42e05d16d860.html' : 'resources/fileCacheBatch_12.js', 
        '7f2d38de-98c6-48ee-a9c4-3641393bf92b.html' : 'resources/fileCacheBatch_12.js', 
        'b49f1d42-191c-45ad-9f86-2582f8898acf.html' : 'resources/fileCacheBatch_12.js', 
        '84101fa0-e3b9-4241-a8f1-fabe5a66ff28.html' : 'resources/fileCacheBatch_12.js', 
        '8a6744af-668b-4d45-b34d-d6486d6a32b4.html' : 'resources/fileCacheBatch_12.js', 
        '53b494f9-b78e-4a94-911c-b7893ff5c5ed.html' : 'resources/fileCacheBatch_13.js', 
        'c2b6f471-1d52-4399-a0ce-9069e002d96e.html' : 'resources/fileCacheBatch_13.js', 
        'c70a429d-37c4-4214-9b95-f2ac8e53ec1d.html' : 'resources/fileCacheBatch_13.js', 
        '1187723e-8254-49e7-a440-cb26ab411c2d.html' : 'resources/fileCacheBatch_13.js', 
        '2ca7d8e2-3a99-4ab8-a19b-46080be0cf46.html' : 'resources/fileCacheBatch_13.js', 
        'b43bcaad-ef72-474a-ae6a-b76f7793c9db.html' : 'resources/fileCacheBatch_14.js', 
        '5f42ad56-faf6-4758-8228-4a19adc919b6.html' : 'resources/fileCacheBatch_14.js' // <--end of repeated part
  };

  // must run only once

  var isCalled = false;

  function startCachingGuids(firstGuid) {
      if (isCalled) {
          return;
      } else {
          isCalled = true;
      }

    var batchPath = guidsBatchMap[firstGuid];

    getDocumentBatch(batchPath)
      .then(function () {
        // load the rest of batches

        batchPathNames
          .filter(function (batchName) {
            return batchPath !== batchName;
          })
          .forEach(function (batchPath) {
            getDocumentBatch(batchPath)
          });
      })
  }

   Object.keys(fileCacheJS)
    .filter(function (guid) {
      return !!fileCacheJS[guid].then;
    })
    .forEach(function (guid) {
      var p = fileCacheJS[guid];

      p.onThen(function () {
        startCachingGuids(guid);
      });
    });

  function getDocumentBatch(path) {
    var promise = createPromise();
    var script = document.createElement('script');

    script.src = path;
    script.async = true;
    script.onload = function () {
      promise.resolve();
    };

    script.onerror = function(err) {
      console.error(err);
      // handle error
      guids.forEach(function(guid) {
        fileCacheJS[guid].reject();
      });

      promise.reject();
    };

    document.body.appendChild(script);

    return promise;
  }

  global.__fileCacheJS = fileCacheJS;

  global.define(fileCacheJS);
})(window);

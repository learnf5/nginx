var SCORM_RESULTS_PAGE = '/ScormEngineInterface/RecordResults.html?configuration=CustomProperties%7Cas%3A1%2Ccs%3A%2Clms%3A&registration=';
var AICC_RESULTS_PAGE = '';
var SERVER_LOGGER_PAGE = '/ScormEngineInterface/Logger.html';
var DEBUG_LOG_PERSIST_PAGE = '/ScormEngineInterface/defaultui/savedebuglog.html?registration=' + escape('') + '&logId=' + escape('554c944b-50c1-4cd2-a6f4-212a873008c5');
var SHOULD_SAVE_CLIENT_DEBUG_LOGS = false;
var ERROR_REPORT_FORM_URL = '';
var SSP_ENABLED = true;
var MAX_SSP_STORAGE = '0';
var SCORMENGINE_SCRIPTS_URL = 'scripts';

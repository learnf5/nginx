const uglify = require('uglify-js');
const glob = require('glob');
const fs = require('fs');
const outputFileName = '../../JavascriptPlayer/PLAYER.js';
const outputMapName = '../../JavascriptPlayer/PLAYER.js.map';

var Concat = require('concat-with-sourcemaps');
var requiredFiles = [
    'playerconst.js',
    'DefaultIntegration.js',
    'lz77.js',
];

glob('core/**/*.js', {}, function (err, files) {
    var concat, config, result;

    if (err) {
        throw error;
    }

    concat = new Concat(true, 'bundle.js', '\n');

    requiredFiles = requiredFiles.concat(files);

    requiredFiles.forEach(function (filename) {
        concat.add(filename, fs.readFileSync(filename, 'UTF-8'));
    });

    config = JSON.parse(fs.readFileSync('uglify.config.json', 'UTF-8'));
    config.sourceMap.content = concat.sourceMap;

    result = uglify.minify(concat.content.toString(), config);

    if (result.error) throw result.error;

    fs.writeFileSync(outputFileName, result.code, 'UTF-8');
    fs.writeFileSync(outputMapName, result.map, 'UTF-8');
});

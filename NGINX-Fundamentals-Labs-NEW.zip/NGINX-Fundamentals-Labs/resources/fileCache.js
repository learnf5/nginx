(function(global) {
  // fileCache.js without query param "guids"

  var fileCacheJS = {

    /**
    * The pattern below, everything between {_{#guids}_} and {_{/guids}_} will be repeated for every item of the "guids" collection.
    * {_{.}_} (without _) will be replaced with the item of the collection "guids", which is defined in the "context", see JsFileCacheWriter.java
    * the result will look like this:
    * '4ef18c14-40ec-4443-b0a5-1c0d5c7b8702.html': createPromise(),
    * 'a26a1d7d-7f7f-488e-b5dc-be9830c07db6.html': createPromise(),
    * .....
    * 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx.html': createPromise(),
    * for more info see https://mustache.github.io/
    */
    // 
    '85593825-be3a-421b-a503-6aba2d0c589b.html': createPromise(), 
    '9e392050-6e87-4b3a-a904-cf37c7448440.html': createPromise(), 
    'f6178495-dcf5-4f23-8a0d-208e50e21029.html': createPromise(), 
    'f2328b2c-af24-41a7-ace8-b6723e10bd64.html': createPromise(), 
    '6318c2cd-eded-4911-baea-494856fa366e.html': createPromise(), 
    '98038ca0-b1e9-41c9-b77b-e0446a8a4a42.html': createPromise(), 
    'ef103d05-8898-48a9-89ca-8d214ac413ec.html': createPromise(), 
    '5c0c2b8f-41cf-4372-a19f-602811433fa2.html': createPromise(), 
    'd7290b3a-2bd3-44d8-951b-6c868745ca33.html': createPromise(), 
    'f4dcffa0-9fc9-430d-9905-dd56cfa1e060.html': createPromise(), 
    'aaf9b820-f51d-44d7-a075-5d9ef849e116.html': createPromise(), 
    'c909b046-31b5-492d-a7e8-50840f2f02f9.html': createPromise(), 
    '8193d29b-d3f7-4972-902f-0646bf0ae875.html': createPromise(), 
    '53ead6ad-2e59-4c5f-815e-19df331a7502.html': createPromise(), 
    '5a2aaeb7-0575-42fc-87f6-bedb4b626857.html': createPromise(), 
    '064c8652-b7ff-4bc2-a766-abd3024b8dcb.html': createPromise(), 
    '74c70a6a-e3ac-43d4-9845-9fcc6ad25906.html': createPromise(), 
    'c73f84d0-ed98-4a81-88ff-0cc0df24b5da.html': createPromise(), 
    '72b6cbf3-01ee-4e34-a67c-d672cd022582.html': createPromise(), 
    'dec21b66-80c8-4719-b848-43b656a7f23c.html': createPromise(), 
    'e18abe82-1256-4c7c-b6d0-4748579e68ec.html': createPromise(), 
    '7f2d38de-98c6-48ee-a9c4-3641393bf92b.html': createPromise(), 
    'ab9538cb-6244-4be1-818b-dd00e10ec3fb.html': createPromise(), 
    'b570c608-79ca-400b-800b-2adc42746ecb.html': createPromise(), 
    'f69e109e-5e71-4ce4-85c4-824ab73c19c8.html': createPromise(), 
    '9ac066c3-ed5f-4905-8963-25d5c5819b70.html': createPromise(), 
    '8a6744af-668b-4d45-b34d-d6486d6a32b4.html': createPromise(), 
    '18af083f-dace-4065-b6ef-9c134031a852.html': createPromise(), 
    '2c52cb90-8bcd-4df7-b9d1-eedf33d8f7fc.html': createPromise(), 
    '794aa9b0-00cc-4459-9330-9d0e96b5e631.html': createPromise(), 
    'ccd058e2-e4a3-4a98-91a5-5d619ec5b99a.html': createPromise(), 
    '15a22bc6-73fc-4fca-a14d-0380bb7aa554.html': createPromise(), 
    'a9956d22-3d14-4a68-aaec-6d289b3716e6.html': createPromise(), 
    '24415f35-5369-40e6-9797-e1db1bd8d936.html': createPromise(),  //<-- end of repeated part

    resolve: function fileCacheJSResolve(guid, content) {
      var promise = fileCacheJS[guid];

      if (!promise) {
        // log error
        return;
      }

      promise.resolve(content);
    }
  };

  function createPromise() {
    var resolve;
    var reject;

    var p = new Promise(function(res, rej) {
      resolve = res;
      reject = rej;
    });

    p.resolve = resolve;
    p.reject = reject;
    var then = p.then.bind(p);

    var listeners = [];

    p.onThen = function (listener) {
      listeners.push(listener);
    };

    p.then = function (success, failed) { // detect when called
      listeners.forEach(function (fn) {
        fn();
      });

      return then(success, failed);
    };

    return p;
  }


    /**
     * The pattern below, everything between {_{#batchPathNames}_} and {_{/batchPathNames}_} will be expanded to the array of string
     * using the content of the "batchPathNames" collection. The result will look like this:
     * batchPathNames = ['resources/fileCacheBatch_1.js', 'resources/fileCacheBatch_2.js', ...'resources/fileCacheBatch_N.js'];
     * see JsFileCacheWriter.java and https://mustache.github.io/
     */
  var batchPathNames = [
      // 
      'resources/fileCacheBatch_5.js', 
      'resources/fileCacheBatch_2.js', 
      'resources/fileCacheBatch_1.js', 
      'resources/fileCacheBatch_7.js', 
      'resources/fileCacheBatch_6.js', 
      'resources/fileCacheBatch_3.js', 
      'resources/fileCacheBatch_4.js'  //<--end of repeated part
      ];

    /**
     * The pattern below, everything between {_{#guidBatchMap}_} and {_{/guidBatchMap}_} will be expanded to the map of string to string
     * using the content of the "guidBatchMap" map. The result will look like this:
     * guidsBatchMap = {
     * '4ef18c14-40ec-4443-b0a5-1c0d5c7b8702.html' : 'resources/fileCacheBatch_1.js',
     * 'a26a1d7d-7f7f-488e-b5dc-be9830c07db6.html' : 'resources/fileCacheBatch_2.js',
     * ....
     * 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx.html' : 'resources/fileCacheBatch_N.js'
     * };
     * see JsFileCacheWriter.java and https://mustache.github.io/
     */
  var guidsBatchMap = {
    // 
        '85593825-be3a-421b-a503-6aba2d0c589b.html' : 'resources/fileCacheBatch_1.js', 
        '9e392050-6e87-4b3a-a904-cf37c7448440.html' : 'resources/fileCacheBatch_1.js', 
        'f6178495-dcf5-4f23-8a0d-208e50e21029.html' : 'resources/fileCacheBatch_1.js', 
        'f2328b2c-af24-41a7-ace8-b6723e10bd64.html' : 'resources/fileCacheBatch_1.js', 
        '6318c2cd-eded-4911-baea-494856fa366e.html' : 'resources/fileCacheBatch_1.js', 
        '98038ca0-b1e9-41c9-b77b-e0446a8a4a42.html' : 'resources/fileCacheBatch_2.js', 
        'ef103d05-8898-48a9-89ca-8d214ac413ec.html' : 'resources/fileCacheBatch_2.js', 
        '5c0c2b8f-41cf-4372-a19f-602811433fa2.html' : 'resources/fileCacheBatch_2.js', 
        'd7290b3a-2bd3-44d8-951b-6c868745ca33.html' : 'resources/fileCacheBatch_2.js', 
        'f4dcffa0-9fc9-430d-9905-dd56cfa1e060.html' : 'resources/fileCacheBatch_2.js', 
        'aaf9b820-f51d-44d7-a075-5d9ef849e116.html' : 'resources/fileCacheBatch_3.js', 
        'c909b046-31b5-492d-a7e8-50840f2f02f9.html' : 'resources/fileCacheBatch_3.js', 
        '8193d29b-d3f7-4972-902f-0646bf0ae875.html' : 'resources/fileCacheBatch_3.js', 
        '53ead6ad-2e59-4c5f-815e-19df331a7502.html' : 'resources/fileCacheBatch_3.js', 
        '5a2aaeb7-0575-42fc-87f6-bedb4b626857.html' : 'resources/fileCacheBatch_3.js', 
        '064c8652-b7ff-4bc2-a766-abd3024b8dcb.html' : 'resources/fileCacheBatch_4.js', 
        '74c70a6a-e3ac-43d4-9845-9fcc6ad25906.html' : 'resources/fileCacheBatch_4.js', 
        'c73f84d0-ed98-4a81-88ff-0cc0df24b5da.html' : 'resources/fileCacheBatch_4.js', 
        '72b6cbf3-01ee-4e34-a67c-d672cd022582.html' : 'resources/fileCacheBatch_4.js', 
        'dec21b66-80c8-4719-b848-43b656a7f23c.html' : 'resources/fileCacheBatch_4.js', 
        'e18abe82-1256-4c7c-b6d0-4748579e68ec.html' : 'resources/fileCacheBatch_5.js', 
        '7f2d38de-98c6-48ee-a9c4-3641393bf92b.html' : 'resources/fileCacheBatch_5.js', 
        'ab9538cb-6244-4be1-818b-dd00e10ec3fb.html' : 'resources/fileCacheBatch_5.js', 
        'b570c608-79ca-400b-800b-2adc42746ecb.html' : 'resources/fileCacheBatch_5.js', 
        'f69e109e-5e71-4ce4-85c4-824ab73c19c8.html' : 'resources/fileCacheBatch_5.js', 
        '9ac066c3-ed5f-4905-8963-25d5c5819b70.html' : 'resources/fileCacheBatch_6.js', 
        '8a6744af-668b-4d45-b34d-d6486d6a32b4.html' : 'resources/fileCacheBatch_6.js', 
        '18af083f-dace-4065-b6ef-9c134031a852.html' : 'resources/fileCacheBatch_6.js', 
        '2c52cb90-8bcd-4df7-b9d1-eedf33d8f7fc.html' : 'resources/fileCacheBatch_6.js', 
        '794aa9b0-00cc-4459-9330-9d0e96b5e631.html' : 'resources/fileCacheBatch_6.js', 
        'ccd058e2-e4a3-4a98-91a5-5d619ec5b99a.html' : 'resources/fileCacheBatch_7.js', 
        '15a22bc6-73fc-4fca-a14d-0380bb7aa554.html' : 'resources/fileCacheBatch_7.js', 
        'a9956d22-3d14-4a68-aaec-6d289b3716e6.html' : 'resources/fileCacheBatch_7.js', 
        '24415f35-5369-40e6-9797-e1db1bd8d936.html' : 'resources/fileCacheBatch_7.js' // <--end of repeated part
  };

  // must run only once

  var isCalled = false;

  function startCachingGuids(firstGuid) {
      if (isCalled) {
          return;
      } else {
          isCalled = true;
      }

    var batchPath = guidsBatchMap[firstGuid];

    getDocumentBatch(batchPath)
      .then(function () {
        // load the rest of batches

        batchPathNames
          .filter(function (batchName) {
            return batchPath !== batchName;
          })
          .forEach(function (batchPath) {
            getDocumentBatch(batchPath)
          });
      })
  }

   Object.keys(fileCacheJS)
    .filter(function (guid) {
      return !!fileCacheJS[guid].then;
    })
    .forEach(function (guid) {
      var p = fileCacheJS[guid];

      p.onThen(function () {
        startCachingGuids(guid);
      });
    });

  function getDocumentBatch(path) {
    var promise = createPromise();
    var script = document.createElement('script');

    script.src = path;
    script.async = true;
    script.onload = function () {
      promise.resolve();
    };

    script.onerror = function(err) {
      console.error(err);
      // handle error
      guids.forEach(function(guid) {
        fileCacheJS[guid].reject();
      });

      promise.reject();
    };

    document.body.appendChild(script);

    return promise;
  }

  global.__fileCacheJS = fileCacheJS;

  global.define(fileCacheJS);
})(window);

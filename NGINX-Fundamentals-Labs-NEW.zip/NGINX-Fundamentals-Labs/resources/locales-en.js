define({"en": {
    "components": {
        "bibliography": {"title": {"message": "Bibliography"}},
        "calculator": {"title": {"message": "Calculator"}},
        "completionApi": {"alert": {"message": "Please complete all activities before proceeding"}},
        "courseProgress": {
            "delimeter": {"message": "of"},
            "title": {"message": "Course Progress"}
        },
        "courseResources": {"title": {"message": "Course Resources"}},
        "exitButton": {
            "confirm": {"message": "Are you sure you want to exit the course? Your progress will be saved."},
            "confirmNoSave": {"message": "Are you sure you want to exit the course?"},
            "confirmTimerOn": {"message": "Are you sure you want to exit the course? The timer will continue to count down, even if the course is closed."},
            "title": {"message": "Exit"}
        },
        "glossary": {"title": {"message": "Glossary"}},
        "mainMenu": {"title": {"message": "Main Menu"}},
        "mute": {
            "mute": {"message": "Mute"},
            "title": {"message": "Mute"},
            "unmute": {"message": "Unmute"}
        },
        "narration": {"title": {"message": "Narration"}},
        "navigation": {"title": {"message": "Navigation"}},
        "navigationButtons": {
            "back": {"message": "Back"},
            "backDisabledMessage": {"message": "The previous page is not available at this time. Use the table of contents to navigate to a different page."},
            "next": {"message": "Next"},
            "nextDisabledMessage": {"message": "The next page is not available at this time. Use the table of contents to navigate to a different page."},
            "title": {"message": "Navigation"}
        },
        "navigationTree": {"title": {"message": "Navigation"}},
        "notebook": {"title": {"message": "Notebook"}},
        "pageResources": {
            "linkTitle": {"message": "Link"},
            "popupTitle": {"message": "Page Resources"},
            "resourceTitle": {"message": "Resource"},
            "title": {"message": "Page Resources"}
        },
        "print": {"title": {"message": "Print"}},
        "resource": {
            "classroomSetupProcedure": {"message": "Classroom Setup Procedure"},
            "exercise": {
                "description": "An activity in order to strengthen a learner\u2019s understanding of a concept. Doesn\u2019t necessarily mean \u201cphysical exercise\u201d for health purposes",
                "message": "Exercise"
            },
            "exerciseSolution": {"message": "Exercise Solution"},
            "instructorNote": {"message": "Instructor Note"},
            "noType": {"message": "No type selected"}
        },
        "resources": {"title": {"message": "Resources"}},
        "sectionStatus": {
            "status": {
                "attempted": {"message": "Attempted"},
                "notattempted": {"message": "Not Attempted"},
                "skipped": {"message": "Skipped"}
            },
            "title": {"message": "Section Status"}
        },
        "staticPage": {"title": {"message": "Static Page"}},
        "submitAllButton": {
            "acceptanceCheck": {
                "description": "label for check box to reassure learner know that all questions are going to be submitted",
                "message": "I understand that any unanswered questions will also be submitted"
            },
            "confirm": {"message": "Do you really want to submit all of your answers?"},
            "info": {"message": "Please review your responses prior to submission. Once you have submitted your responses you will not be able to change them."},
            "title": {"message": "Submit All"}
        },
        "timer": {
            "finishText": {"message": "The time allocated for this assessment has expired. All questions (answered and unanswered) will now be submitted for evaluation."},
            "label": {"message": "Remaining Time:"},
            "startText": {"message": "This is a timed assessment. When time expires, all questions (answered and unanswered) will automatically be submitted for evaluation."},
            "title": {"message": "Timer"}
        }
    },
    "datepicker": {
        "days": {
            "Friday": {"message": "Friday"},
            "Monday": {"message": "Monday"},
            "Saturday": {"message": "Saturday"},
            "Sunday": {"message": "Sunday"},
            "Thursday": {"message": "Thursday"},
            "Tuesday": {"message": "Tuesday"},
            "Wednesday": {"message": "Wednesday"}
        },
        "months": {
            "April": {"message": "April"},
            "August": {"message": "August"},
            "December": {"message": "December"},
            "February": {"message": "February"},
            "January": {"message": "January"},
            "July": {"message": "July"},
            "June": {"message": "June"},
            "March": {"message": "March"},
            "May": {"message": "May"},
            "November": {"message": "November"},
            "October": {"message": "October"},
            "September": {"message": "September"}
        },
        "nextmonth": {"message": "Next Month"},
        "previousmonth": {"message": "Previous Month"},
        "shortDays": {
            "Fri": {"message": "Fri"},
            "Mon": {"message": "Mon"},
            "Sat": {"message": "Sat"},
            "Sun": {"message": "Sun"},
            "Thu": {"message": "Thu"},
            "Tue": {"message": "Tue"},
            "Wed": {"message": "Wed"}
        }
    },
    "elements": {
        "AutoNumberToken": {
            "activity": {"message": "Activity"},
            "figure": {"message": "Figure"},
            "table": {"message": "Table"}
        },
        "FAQ": {
            "questionPrefix": {
                "description": "Prefixes a question in the FAQ element",
                "message": "Q"
            },
            "shortAnswerPrefix": {
                "description": "Prefixes a short answer in the FAQ element",
                "message": "A"
            },
            "supplementLinksTitle": {"message": "Related Information"}
        },
        "accordionTabs": {
            "mustBeCompletedMessage": {"message": "Please view all the tabs before proceeding."},
            "submit": {"message": "Submit"}
        },
        "carouselTabs": {"mustBeCompletedMessage": {"message": "Please view all slides before proceeding."}},
        "categories": {"mustBeCompletedMessage": {"message": "Please view all categories before proceeding."}},
        "choiceBranch": {
            "mustBeCompletedMessage": {"message": "Please provide a response before proceeding."},
            "submit": {"message": "Submit"}
        },
        "citation": {
            "noType": {"message": "Reference"},
            "title": {"message": "Citation"}
        },
        "docWriter": {
            "advice": {"message": "Advice"},
            "charsLeft": {"message": "characters left"},
            "click": {"message": "Click"},
            "generateDocument": {"message": "Generate Document"},
            "here": {"message": "here"},
            "hint": {"message": "Hint"},
            "modelResponseTitle": {"message": "Show Model Response"},
            "moreInfo": {"message": "for more info"},
            "print": {"message": "Print"},
            "startOver": {"message": "Start Over"},
            "startOverConfirmMessage": {"message": "Are you sure you want to clear the form and start over?"},
            "title": {"message": "DocWriter"}
        },
        "flashcards": {
            "accessibilityChooseMode": {"message": "Choose Mode"},
            "accessibilityFirst": {"message": "First"},
            "accessibilityLast": {"message": "Last"},
            "accessibilityNext": {"message": "Next"},
            "accessibilityPrev": {"message": "Previous"},
            "chooseMode": {"message": "Choose Mode"},
            "correct": {"message": "Correct"},
            "incorrect": {"message": "Incorrect"},
            "learnMode": {"message": "Learn"},
            "mustBeCompletedMessage": {"message": "Please visit all flash cards before proceeding."},
            "practiceMode": {"message": "Practice"},
            "submit": {"message": "Submit"},
            "testMode": {"message": "Test"}
        },
        "imagemap": {"mustBeCompletedMessage": {"message": "Please visit all hotspots before proceeding."}},
        "inlineHotText": {"title": {"message": " "}},
        "media": {
            "audioPlayer": {"message": "Audio Player"},
            "captionsChapters": {"message": "Chapters"},
            "captionsSubtitles": {"message": "Captions/Subtitles"},
            "close": {"message": "Close"},
            "downloadFile": {"message": "Download File"},
            "downloadVideo": {"message": "Download Video"},
            "fullscreen": {"message": "Fullscreen"},
            "goFullscreen": {"message": "Go Fullscreen"},
            "installFlash": {"message": "You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https://get.adobe.com/flashplayer/"},
            "liveBroadcast": {"message": "Live Broadcast"},
            "mustBeCompletedMessage": {"message": "Please allow the media to finish before attempting to proceed."},
            "mute": {"message": "Mute"},
            "muteToggle": {"message": "Mute Toggle"},
            "none": {"message": "None"},
            "pause": {"message": "Pause"},
            "play": {"message": "Play"},
            "playPause": {"message": "Play/Pause"},
            "playbackError": {"message": "Error: unable to play media"},
            "sceneAudioTitle": {
                "description": "Used as a separation title for scene Audio descriptions within an A/V script element.",
                "message": "Audio"
            },
            "sceneNotesTitle": {
                "description": "Used as a separation title for scene notes within an A/V script element.",
                "message": "Notes"
            },
            "sceneScreenTitle": {
                "description": "Used as a separation title for scene Screen descriptions within an A/V script element.",
                "message": "Screen"
            },
            "sceneTitle": {
                "description": "Used as a separation title for scenes within an A/V script element. Will be followed by a number corresponding to its position in the XML",
                "message": "Scene"
            },
            "timeHelpText": {"message": "Use Left/Right Arrow keys to advance one second, Up/Down arrows to advance ten seconds."},
            "timeSlider": {"message": "Time Slider"},
            "turnOffFullscreen": {"message": "Turn off Fullscreen"},
            "unmute": {"message": "Unmute"},
            "videoPlayer": {"message": "Video Player"},
            "volumeHelpText": {"message": "Use Up/Down Arrow keys to increase or decrease volume."},
            "volumeSlider": {"message": "Volume Slider"}
        },
        "notification": {
            "cancel": {"message": "Cancel"},
            "ok": {"message": "OK"}
        },
        "procedure": {"stepTitle": {
            "description": "Used as the title for each Procedure step",
            "message": "Step"
        }},
        "tabs": {"mustBeCompletedMessage": {"message": "Please view all tabs before proceeding."}},
        "xref": {"404": {"message": "This content is currently unavailable. Please contact your administrator referencing GUID: "}}
    },
    "general": {
        "back": {"message": "Back"},
        "cancel": {"message": "Cancel"},
        "close": {"message": "Close"},
        "companyLogo": {
            "description": "alt text for company logo image",
            "message": "NGINX, Part of F5"
        },
        "content": {
            "description": "content region description for 508c",
            "message": "Main Content"
        },
        "copyright": {"message": "Copyright © F5, Inc. All rights reserved."},
        "footer": {
            "description": "footer region description for 508c",
            "message": "Footer"
        },
        "gotocontent": {
            "description": "link to content for 508c",
            "message": "Skip to content"
        },
        "header": {
            "description": "header region description for 508c",
            "message": "Header"
        },
        "menu": {
            "description": "menu region description for 508c",
            "message": "Main menu"
        },
        "navigation": {
            "noSuchPage": {
                "description": "User entered hash of non-existent page",
                "message": "There is no page with this ID"
            },
            "notAvailable": {
                "description": "User entered hash of a disabled page",
                "message": "That page is not available"
            }
        },
        "next": {"message": "Next"},
        "ok": {"message": "OK"},
        "sidebarLeft": {
            "description": "sidebarLeft region description for 508c",
            "message": "Left sidebar"
        },
        "sidebarRight": {
            "description": "sidebarRight region description for 508c",
            "message": "Right sidebar"
        },
        "unhandledError": {"message": "A fatal error occurred. Please refresh the page to try again. If this issue continues, please contact an administrator"},
        "unsupportedBrowser": {"message": "This web browser will not provide the best experience for this content. Please use a supported browser to continue."},
        "unsupportedIE": {"message": "It seems you are using either an unsupported version or an unsupported mode of Internet Explorer. Please ensure you are using Internet Explorer 11 (or higher) running in Standards mode."},
        "xylemeCopyright": {"message": "© 2019 Xyleme. All rights reserved."}
    },
    "player": {"cloudPlayer": {"exitMessages": {"proctorConfirm": {
        "description": "Shown to the user when they are exiting a proctored course without the required proctor sign-out.",
        "messsage": "Are you sure you want to exit the course?\nThis is a Proctored course, by leaving this page:\n  * The current attempt will terminate and registered as failed\n  * You will need a new authorization from a Proctor to re-attempt this course"
    }}}},
    "questions": {
        "binDrop": {"displayName": {
            "description": "The Bin Drop question type",
            "message": "Bin Drop"
        }},
        "branchingSim": {
            "displayName": {
                "description": "Branching simulation or branching scenario activity",
                "message": "Branching Simulation"
            },
            "feedback": {"message": "Feedback"},
            "instructions": {"message": "Instructions"},
            "outcome": {"message": "Outcome"},
            "replay": {"message": "Replay"},
            "scenario": {"message": "Scenario"},
            "selectResponseBelow": {"message": "Select a response below to continue."}
        },
        "dragDrop": {"displayName": {
            "description": "The Drag and Drop question type",
            "message": "Drag 'n Drop"
        }},
        "essayActivity": {"displayName": {
            "description": "The Essay question type",
            "message": "Essay"
        }},
        "fillInBlank": {"displayName": {
            "description": "The Fill in the Blank question type",
            "message": "Fill In Blank"
        }},
        "general": {
            "copy": {"message": "Copy"},
            "correct": {"message": "Correct!"},
            "correctResponse": {
                "description": "used mainly in response-specific feedback to show correct options which the user did not select",
                "message": "Correct Response"
            },
            "cut": {"message": "Cut"},
            "extraInfo": {"message": "Extra Information"},
            "flag": {"message": "Flag/Unflag this Question"},
            "gate": {"message": "Please answer all questions on the page before attempting navigation"},
            "incorrect": {"message": "Incorrect"},
            "incorrectNotice": {"message": "Incorrect, try again"},
            "myAnswer": {"message": "My Answer"},
            "notify": {"answerQuestion": {"message": "Please attempt to answer the question."}},
            "paste": {"message": "Paste"},
            "showAnswer": {"message": "Show Answer"},
            "showSolution": {"message": "Show Solution"},
            "skip": {
                "confirm": {"message": "Continue Navigation"},
                "confirmationMessage": {"message": "You have not answered all of the questions on the page. Continue with navigation?"},
                "reject": {"message": "Return to Page"}
            },
            "submit": {"message": "Submit"}
        },
        "imageMapAssessment": {"displayName": {
            "description": "A question type asking the user to select the region(s) in an image which is the answer to the question.",
            "message": "ImageMap Assessment"
        }},
        "matchingActivity": {"displayName": {
            "description": "A question type that asks the user to match each option on the left side with the correct option on the rigth side.",
            "message": "Matching Activity"
        }},
        "matrix": {
            "accessibilitySummary": {
                "description": "Same as above, but this time more explicitly states it is a question for screen readers used by disabled people (instead of the screen reader simply stating that it is a standard table).",
                "message": "Matrix Question"
            },
            "displayName": {
                "description": "A question type that is organized as a matrix or table where the user must select one or more columns for each row",
                "message": "Matrix"
            },
            "option": {
                "description": "An option that can be selected in a matrix question which corresponds to a cell in the table",
                "message": "Option"
            }
        },
        "multipleChoice": {"displayName": {
            "description": "The Multiple Choice question type",
            "message": "Multiple Choice"
        }},
        "selectHotText": {"displayName": {
            "description": "A question type asking the user to select one or more words among a set of highlighted words in a passage.",
            "message": "Select Hot Text"
        }},
        "sequenceActivity": {
            "correctResponse": {"message": "Correct response:"},
            "displayName": {
                "description": "A question type which asks the user to put a set of elements in the correct order or sequence.",
                "message": "Sequence Activity"
            },
            "dragHandle": {
                "description": "The drag handle is used in sequencing activities to move around items so they can be put in the correct sequence to answer the question",
                "message": "Drag Handle"
            }
        }
    },
    "regions": {
        "footer": {"title": {"message": "Footer"}},
        "header": {"title": {"message": "Header"}},
        "menu": {"title": {"message": "Menu"}},
        "sidebarLeft": {"title": {"message": "Sidebar Left"}},
        "sidebarRight": {"title": {"message": "Sidebar Right"}}
    },
    "reviewSession": {
        "changedStructure": {"message": "It seems that you have changed the structure of the document. The comment # cannot be highlighted."},
        "close": {"message": "Close"},
        "comment": {"message": "comment"},
        "comments": {"message": "comments"},
        "commentsList": {
            "commentsOnOtherPages": {"title": {"message": "Comments On Other Pages"}},
            "commentsOnThisPage": {"title": {"message": "Comments On This Page"}},
            "endDate": {"message": "End Date"},
            "filter": {
                "allStatuses": {"message": "All Statuses"},
                "allUsers": {"message": "All Users"},
                "byStatus": {"message": "Filter By Status"},
                "byUser": {"message": "Filter By User"},
                "resetFilters": {"message": "Reset Filters"}
            },
            "search": {"message": "Search"},
            "searchById": {"message": "Search By Id"},
            "startDate": {"message": "Start Date"},
            "title": {"message": "Comments List"}
        },
        "reviewSessionFor": {"message": "Review Session for"},
        "status": {
            "approved": {"message": "Flagged For Edit"},
            "completed": {"message": "Completed"},
            "message": "Status ",
            "open": {"message": "Open"},
            "rejected": {"message": "Rejected"}
        },
        "statusChange": {
            "toApproved": {"message": "Flag for Edit"},
            "toCompleted": {"message": "Complete"},
            "toOpen": {"message": "Reopen"},
            "toRejected": {"message": "Reject"}
        },
        "textAreaPlaceholder": {"message": "Add a note..."},
        "title": {"message": "Review Session"},
        "waitForComplete": {"message": "Please wait for previous operation to complete."}
    },
    "sections": {
        "checkPointQuestion": {"title": {"message": "CheckPoint Question"}},
        "checkPointQuestions": {
            "intro": {"message": "CheckPoint Intro"},
            "text1": {"message": "The following questions are designed to check your knowledge on the content of this lesson."},
            "text2": {"message": "Each question has a predefined number of allowed attempts listed next to the Submit button. Questions can be skipped, and you can return to them later. Pay attention to hints and advice as each gives clues to the correct answers."},
            "text3": {"message": "Click Next to start."},
            "title": {"message": "CheckPoint Questions"}
        },
        "coverPage": {"title": {"message": "Page"}},
        "scoreCard": {
            "courseTitle": {"message": "Course Title"},
            "currentScore": {"message": "Current Score"},
            "multipleAttemptsRemaining": {"message": "attempts remaining"},
            "notSupported": {"message": "Scorecard is not supported in current mode."},
            "passingScore": {"message": "Passing Score"},
            "resultNotAvailable": {"message": "N/A"},
            "retake": {"message": "Retake"},
            "retakeAll": {"message": "Retake all"},
            "retakeConfirmation": {"message": "Are you sure you want to retake this assessment?"},
            "reviewPopupTitle": {"message": "Question Review"},
            "sectionTitle": {"message": "Section Title"},
            "sectionWeight": {"message": "Section Weight"},
            "singleAttemptRemaining": {"message": "attempt remaining"},
            "title": {"message": "Scorecard"}
        },
        "summary": {"title": {"message": "Summary"}}
    },
    "visualCue": {"mustBeCompletedMessage": {"message": "Please read the entire page."}}
}});